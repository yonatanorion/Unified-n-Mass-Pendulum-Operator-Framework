"""Supplementary code: tridiagonal structure and exact O(n) dynamics of the planar n-mass pendulum."""
