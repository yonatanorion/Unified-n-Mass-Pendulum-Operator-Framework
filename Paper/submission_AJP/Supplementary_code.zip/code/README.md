# Supplementary code

Python code that reproduces the figures and checks the formulas of the manuscript
"The multiple pendulum as a beaded string: hidden tridiagonal structure from
normal modes to nonlinear dynamics".

Requirements: Python >= 3.9, numpy, scipy, matplotlib, pytest.

    pip install numpy scipy matplotlib pytest
    python -m pytest -q                                  # checks every formula (40 tests)
    python validation/figures_ajp.py --outdir figures    # Figs. 2 and 3

Modules:
- `src/structure.py`: closed-form inverse mass matrix, dynamical matrix Q (Eq. 8), Jacobi matrix J (Eq. 9), normal modes
- `src/chain.py`: tension system and exact nonlinear accelerations (Theorem 2); a RATTLE integrator
- `src/assembly.py`, `src/modal.py`, `src/nonlinear.py`: dense reference formulations used in the tests
- `src/symplectic.py`, `src/propagator.py`: time-stepping utilities used in the tests
