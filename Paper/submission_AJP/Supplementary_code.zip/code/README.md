# Supplementary code

Python code for the manuscript "The multiple pendulum as a beaded string: hidden
tridiagonal structure from normal modes to nonlinear dynamics". It reproduces
Figs. 2 and 3 and checks the main formulas and numerical statements.

Requirements: Python >= 3.9, numpy, scipy, matplotlib, pytest.

    pip install numpy scipy matplotlib pytest
    python -m pytest -q                                  # automated checks
    python validation/figures_ajp.py --outdir figures    # Figs. 2 and 3

Contents:
- `src/minimal.py`: the appendix listing, verbatim
- `src/structure.py`: closed-form inverse mass matrix, dynamical matrix Q (Eq. 8), Jacobi matrix J (Eq. 9), normal modes
- `src/chain.py`: tension system and exact nonlinear accelerations (Theorem 2); also a RATTLE integrator
- `src/assembly.py`, `src/nonlinear.py`: dense reference formulations used by the tests
- `tests/test_paper.py`: node counting, hanging-chain limit (n x relative error -> 1/4), B(0) = L M^-1 L, double-pendulum frequencies, appendix code
